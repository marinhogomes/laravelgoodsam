<?php $__env->startSection('form_title'); ?>
Jobs Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
        <div class="columns is-mobile is-multiline">
          <div class="column is-full">
            <?php echo Form::open(['url' => action('JobController@store')]); ?>

              <?php echo $__env->make('admin.form_job',['button' => 'Create'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo Form::close(); ?>

          </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
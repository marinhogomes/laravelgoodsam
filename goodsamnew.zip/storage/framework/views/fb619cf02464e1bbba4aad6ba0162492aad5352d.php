<?php $__env->startSection('form_title'); ?>
Categories Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
        <div class="columns is-mobile is-multiline">
          <div class="column is-full">
            <?php echo Form::model($category, ['route' => ['category.update', $category->id]]); ?>

              <?php echo $__env->make('admin.form_category',['button' => 'Update'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo Form::close(); ?>

          </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
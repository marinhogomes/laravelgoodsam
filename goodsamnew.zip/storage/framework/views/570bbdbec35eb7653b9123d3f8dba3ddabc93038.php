<?php $__env->startSection('form_title'); ?>
Category Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section class="section">

			<nav class="level">
			  <!-- Left side -->
			  <div class="level-left">
			    <div class="level-item">
			      <div class="field has-addons">
			        <p class="control">
			          <input class="input" type="text" placeholder="Find a user">
			        </p>
			        <p class="control">
			          <button class="button">
			            Search
			          </button>
			        </p>
			      </div>
			    </div>
			  </div>
			  <!-- Right side -->
			  <div class="level-right">
			    <p class="level-item"><a class="button is-success" href="<?php echo e(action('UserController@create')); ?>">Create User</a></p>
			  </div>

			</nav>


	        <div class="columns">
	        	<div class="column is-12">
					<table class="table" style="width: 100%">
					  <thead>
					    <tr>
					      <th>Id</th>
					      <th>Name</th>
					      <th>Action</th>
					    </tr>
					  </thead>
					  <tbody>
					  	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  	<tr>
					  		<th><?php echo e($category->id); ?></th>
					  		<th><?php echo e($category->name); ?></th>
					  		<th><a class="button" href="<?php echo e(action('CategoryController@edit', ['category' => $category->id])); ?>">Editar</a> <a class="button" href="">Deletar</a></th>
					  	</tr>
					  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					  </tbody>
				  </table>
				</div>
	        </div>

	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>